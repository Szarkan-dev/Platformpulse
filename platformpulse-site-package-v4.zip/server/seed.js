const db = require('./db');

const initialServices = [
    { service_number: '12723', type: 'Train', destination: 'New Delhi (NDLS)', origin: 'Hyderabad', scheduled_time: '06:50', estimated_time: '06:50', status: 'On Time', gate_platform: 'Platform 4', delay_minutes: 0, active_passengers: 420, platform_sqft: 1200, seat_capacity: 500, seats_available: 48 },
    { service_number: 'AI-502', type: 'Flight', destination: 'Mumbai (BOM)', origin: 'Delhi', scheduled_time: '07:15', estimated_time: '07:45', status: 'Delayed', gate_platform: 'Gate B12', delay_minutes: 30, active_passengers: 180, platform_sqft: 800, luggage_belt: 'Belt 3', luggage_eta_mins: 12, seat_capacity: 200, seats_available: 12 },
    { service_number: '12626', type: 'Train', destination: 'Kerala Express', origin: 'New Delhi', scheduled_time: '07:30', estimated_time: '07:30', status: 'Boarding', gate_platform: 'Platform 2', delay_minutes: 0, active_passengers: 680, platform_sqft: 1200, seat_capacity: 600, seats_available: 5 },
    { service_number: '6E-214', type: 'Flight', destination: 'Bengaluru (BLR)', origin: 'Kolkata', scheduled_time: '08:00', estimated_time: '08:00', status: 'On Time', gate_platform: 'Gate A04', delay_minutes: 0, active_passengers: 110, platform_sqft: 900, luggage_belt: 'Belt 1', luggage_eta_mins: 5, seat_capacity: 180, seats_available: 34 },
    { service_number: '12951', type: 'Train', destination: 'Rajdhani Express', origin: 'Mumbai Central', scheduled_time: '08:30', estimated_time: '09:15', status: 'Delayed', gate_platform: 'Platform 1', delay_minutes: 45, active_passengers: 890, platform_sqft: 1400, seat_capacity: 550, seats_available: 0 },
    { service_number: 'UK-813', type: 'Flight', destination: 'Chennai (MAA)', origin: 'Delhi', scheduled_time: '08:45', estimated_time: '08:45', status: 'Boarding', gate_platform: 'Gate C07', delay_minutes: 0, active_passengers: 165, platform_sqft: 750, seat_capacity: 160, seats_available: 2 },
    { service_number: '12002', type: 'Train', destination: 'Bhopal Shatabdi', origin: 'New Delhi', scheduled_time: '09:00', estimated_time: '09:00', status: 'On Time', gate_platform: 'Platform 3', delay_minutes: 0, active_passengers: 310, platform_sqft: 1100, seat_capacity: 400, seats_available: 82 },
    { service_number: 'SG-401', type: 'Flight', destination: 'Goa (GOI)', origin: 'Ahmedabad', scheduled_time: '09:20', estimated_time: '10:30', status: 'Delayed', gate_platform: 'Gate B02', delay_minutes: 70, active_passengers: 195, platform_sqft: 650, seat_capacity: 189, seats_available: 15 },
    { service_number: '12260', type: 'Train', destination: 'Duronto Express', origin: 'Sealdah', scheduled_time: '09:40', estimated_time: '09:40', status: 'On Time', gate_platform: 'Platform 8', delay_minutes: 0, active_passengers: 240, platform_sqft: 1300, seat_capacity: 480, seats_available: 110 },
    { service_number: 'IX-112', type: 'Flight', destination: 'Dubai (DXB)', origin: 'Kochi', scheduled_time: '10:05', estimated_time: '10:05', status: 'On Time', gate_platform: 'Gate D15', delay_minutes: 0, active_passengers: 210, platform_sqft: 1000, luggage_belt: 'Belt 5', luggage_eta_mins: 22, seat_capacity: 220, seats_available: 19 }
];

const insertStmt = db.prepare(`
    INSERT OR REPLACE INTO TransitServices 
    (service_number, type, destination, origin, scheduled_time, estimated_time, status, gate_platform, delay_minutes, active_passengers, platform_sqft, luggage_belt, luggage_eta_mins, seat_capacity, seats_available)
    VALUES (@service_number, @type, @destination, @origin, @scheduled_time, @estimated_time, @status, @gate_platform, @delay_minutes, @active_passengers, @platform_sqft, @luggage_belt, @luggage_eta_mins, @seat_capacity, @seats_available)
`);

const insertDelayHist = db.prepare(`
    INSERT INTO DelayHistory (service_number, scheduled_hour, weather_condition, track_congestion_level, was_delayed, delay_duration)
    VALUES (?, ?, ?, ?, ?, ?)
`);

const seedTransaction = db.transaction(() => {
    for (const service of initialServices) {
        insertStmt.run(service);
        // Seed historical delay records for mathematical heuristic
        for (let i = 0; i < 10; i++) {
            const wasDelayed = (service.status === 'Delayed' ? (Math.random() > 0.3 ? 1 : 0) : (Math.random() > 0.8 ? 1 : 0));
            insertDelayHist.run(service.service_number, parseInt(service.scheduled_time.split(':')[0]), 'Clear', Math.floor(Math.random() * 5) + 1, wasDelayed, wasDelayed ? Math.floor(Math.random() * 45) + 10 : 0);
        }
    }
});

seedTransaction();
console.log("Database seeded successfully with 3-tier relational schema.");
