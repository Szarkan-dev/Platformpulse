const Database = require('better-sqlite3');
const fs = require('fs');
const path = require('path');

const dbPath = osEnvDbPath() || path.join(__dirname, 'platformpulse.db');
const db = new Database(dbPath);

function osEnvDbPath() {
    return process.env.DB_PATH ? path.resolve(process.env.DB_PATH) : null;
}

// Initialize database schema
const schemaSql = fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf-8');
db.exec(schemaSql);

module.exports = db;
