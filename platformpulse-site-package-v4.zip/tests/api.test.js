const request = require('supertest');
const app = require('../server/server');
const db = require('../server/db');

describe('PlatformPulse 3-Tier SQLite & API Test Suite', () => {
    beforeAll(() => {
        // Ensure test database is seeded
        require('../server/seed');
    });

    test('1. GET /api/services returns 200 with SQL Pagination and Enhanced Heuristics', async () => {
        const res = await request(app).get('/api/services?page=1&limit=5');
        expect(res.statusCode).toEqual(200);
        expect(res.body.status).toEqual('success');
        expect(res.body.data.length).toBeLessThanOrEqual(5);
        expect(res.body.pagination).toHaveProperty('total');
        
        // Assert heuristic mathematical calculations are present
        const first = res.body.data[0];
        expect(first).toHaveProperty('crowdIndex');
        expect(first).toHaveProperty('crowdCategory');
        expect(first).toHaveProperty('delayProbability');
        expect(typeof first.delayProbability).toBe('number');
    });

    test('2. POST /api/simulate validates inputs strictly and rejects invalid actions', async () => {
        const res = await request(app)
            .post('/api/simulate')
            .send({ serviceNumber: '12723', action: 'invalid_action_type' });
        
        expect(res.statusCode).toEqual(400);
        expect(res.body.status).toEqual('error');
        expect(res.body.errors).toBeDefined();
    });

    test('3. POST /api/simulate gate_change correctly updates SQLite database and returns payload', async () => {
        const res = await request(app)
            .post('/api/simulate')
            .send({ serviceNumber: '12723', action: 'gate_change', newGate: 'Platform 9' });

        expect(res.statusCode).toEqual(200);
        expect(res.body.data.newGate).toEqual('Platform 9');

        // Verify SQLite database persistence directly
        const dbRow = db.prepare('SELECT gate_platform FROM TransitServices WHERE service_number = ?').get('12723');
        expect(dbRow.gate_platform).toEqual('Platform 9');
    });

    test('4. Delay Probability Heuristic correctly calculates percentage from history', () => {
        const res = db.prepare('SELECT COUNT(*) as total, SUM(was_delayed) as delayed_count FROM DelayHistory WHERE service_number = ?').get('12723');
        expect(res.total).toBeGreaterThan(0);
        const ratio = (res.delayed_count / res.total) * 100;
        expect(ratio).toBeGreaterThanOrEqual(0);
        expect(ratio).toBeLessThanOrEqual(100);
    });
});
