const { useState, useEffect } = React;

const INITIAL_SERVICES = [
  { id: 'FL-802', type: 'flight', origin: 'London LHR', time: '14:20', est: '14:20', status: 'On Time', gate: 'B12', seats: 84, carousel: 'Belt 4 (08 min)', density: 'Low' },
  { id: 'TR-109', type: 'train', origin: 'Paris Nord', time: '14:35', est: '14:50', status: 'Delayed', gate: 'Plat 3', seats: 12, carousel: 'N/A', density: 'Packed' },
  { id: 'FL-440', type: 'flight', origin: 'Tokyo HND', time: '14:45', est: '14:45', status: 'Boarding', gate: 'A08', seats: 0, carousel: 'Belt 1 (02 min)', density: 'Moderate' },
  { id: 'TR-304', type: 'train', origin: 'Amsterdam Centraal', time: '15:00', est: '15:00', status: 'On Time', gate: 'Plat 7', seats: 65, carousel: 'N/A', density: 'Low' },
  { id: 'FL-911', type: 'flight', origin: 'New York JFK', time: '15:15', est: '15:40', status: 'Delayed', gate: 'C22', seats: 41, carousel: 'Belt 2 (18 min)', density: 'Moderate' },
];

function PlatformPulseApp() {
  const [services, setServices] = useState(INITIAL_SERVICES);
  const [filter, setFilter] = useState('all');
  const [watchlist, setWatchlist] = useState([]);
  const [alert, setAlert] = useState('LIVE FEED: All terminal platform systems nominal.');

  const toggleWatchlist = (id) => {
    setWatchlist(prev => prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]);
  };

  const filteredServices = services.filter(s => {
    if (filter === 'train') return s.type === 'train';
    if (filter === 'flight') return s.type === 'flight';
    if (filter === 'delayed') return s.status === 'Delayed';
    if (filter === 'watchlist') return watchlist.includes(s.id);
    return true;
  });

  return (
    <div className="app-container">
      <header className="terminal-header">
        <div>
          <h1 className="brand-title">✈️ 🚆 PLATFORMPULSE TERMINAL</h1>
          <p className="brand-sub">Real-Time Transit Board & Passenger Wayfinding System</p>
        </div>
        <div style={{ textAlign: 'right' }}>
          <span className="flap-cell">LIVE SYNC ACTIVE</span>
        </div>
      </header>

      <div style={{ background: '#7f1d1d', color: '#fca5a5', padding: '0.75rem 1rem', borderRadius: '6px', marginBottom: '1.5rem', border: '1px solid #ef4444' }}>
        <strong>⚠️ TERMINAL BROADCAST:</strong> {alert}
      </div>

      <div className="controls-bar">
        <button className={`btn ${filter==='all'?'active':''}`} onClick={()=>setFilter('all')}>All Journeys</button>
        <button className={`btn ${filter==='flight'?'active':''}`} onClick={()=>setFilter('flight')}>Flights ✈️</button>
        <button className={`btn ${filter==='train'?'active':''}`} onClick={()=>setFilter('train')}>Trains 🚆</button>
        <button className={`btn ${filter==='delayed'?'active':''}`} onClick={()=>setFilter('delayed')}>Delays ⚠️</button>
        <button className={`btn ${filter==='watchlist'?'active':''}`} onClick={()=>setFilter('watchlist')}>Pinned ({watchlist.length}) ⭐</button>
      </div>

      <div className="board-container">
        <table className="board-table">
          <thead>
            <tr>
              <th>SERVICE</th>
              <th>ORIGIN / DESTINATION</th>
              <th>SCHED</th>
              <th>EST</th>
              <th>GATE / PLAT</th>
              <th>STATUS</th>
              <th>SEAT AVAILABILITY</th>
              <th>LUGGAGE CAROUSEL</th>
              <th>CROWD DENSITY</th>
              <th>PIN</th>
            </tr>
          </thead>
          <tbody>
            {filteredServices.map(s => (
              <tr key={s.id}>
                <td><span className="flap-cell">{s.id}</span></td>
                <td><strong>{s.origin}</strong></td>
                <td>{s.time}</td>
                <td><span style={{ color: s.status === 'Delayed' ? '#ef4444' : '#10b981' }}>{s.est}</span></td>
                <td><span className="flap-cell">{s.gate}</span></td>
                <td>
                  <span className={`badge ${s.status==='On Time'?'badge-ontime':s.status==='Delayed'?'badge-delayed':'badge-boarding'}`}>
                    {s.status}
                  </span>
                </td>
                <td>
                  <div className="seat-bar">
                    <div className="seat-fill" style={{ width: `${s.seats}%` }}></div>
                  </div>
                  <span className="seat-text">{s.seats}% Left</span>
                </td>
                <td>
                  <span className="carousel-countdown">{s.carousel}</span>
                </td>
                <td>
                  <span style={{ color: s.density === 'Packed' ? '#ef4444' : s.density === 'Moderate' ? '#fbbf24' : '#10b981' }}>
                    ● {s.density}
                  </span>
                </td>
                <td>
                  <button className="btn" style={{ padding: '0.2rem 0.5rem' }} onClick={() => toggleWatchlist(s.id)}>
                    {watchlist.includes(s.id) ? '★ Pinned' : '☆ Pin'}
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<PlatformPulseApp />);
