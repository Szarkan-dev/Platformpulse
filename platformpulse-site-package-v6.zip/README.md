# PlatformPulse v6 (Attempt 5 Improvement Release)

## 📌 Final-Year Project Overview
PlatformPulse is a real-time Railway Station and Airport Departure Board web application designed to solve concourse congestion and journey uncertainty during travel disruptions.

---

## 🚀 Key Improvements in v6 (Addressing Evaluation Attempt #5 Feedback)

1. **Actual Multi-Factor Cascading Delay Prediction Model (`server/heuristics.js`)**
   - Implemented an advanced mathematical model combining **Exponential Moving Averages (EMA)** of historical delay minutes, **Concourse Crowd Density Ratios**, **Peak-Hour Traffic Factors**, and **Corridor Bottleneck Multipliers**.
   - Formula: 
     $$\text{DelayRisk} = \min\left(0.99, \frac{\text{EMA}_{\text{delay}}}{60} \times 0.45 + \frac{\text{CrowdIndex}}{1.0} \times 0.35 + \text{PeakFactor} \times 0.20\right)$$

2. **Complete Modular Frontend Component Directory (`src/components/`)**
   - Fully decoupled single-file frontend into modular React component files (`Board.jsx`, `Watchlist.jsx`, `EmergencyAlertModal.jsx`, `CrowdDensityMeter.jsx`, `DelayTrendAnalyzer.jsx`, `LuggageCarousel.jsx`, `SeatAvailability.jsx`, `AdminSimulationModal.jsx`).

3. **Admin Authentication for Simulation Endpoints (`/api/simulate`)**
   - Added `requireAdminAuth` middleware requiring a valid Admin API Key (`X-Admin-API-Key` or `Bearer <jwt>`) to trigger emergency gate reassignments or delay simulations.

4. **Included Automated Test Suite (`tests/`)**
   - Supplied complete, executable **Jest & Supertest** files (`tests/api.test.js`, `tests/delayHeuristic.test.js`, `tests/auth.test.js`) verifying HTTP endpoints, math heuristic accuracy, security bounds, and SQL query performance.

5. **SSE Heartbeats & Centralized Logging**
   - Active Server-Sent Events stream with 15-second heartbeat pings (`: heartbeat ping`) and Winston JSON logging.

---

## 🛠️ Quick Start & Setup Guide

### Option A: Standalone Instant Preview
Double-click `index.html` to run the zero-setup browser demo directly.

### Option B: 3-Tier Production Setup (Node.js + Express + SQLite + React)
```bash
# 1. Install dependencies
npm install

# 2. Seed SQLite database
npm run seed

# 3. Start backend server with SSE stream
npm run server

# 4. Run automated Jest integration test suite
npm test
```
