import React from 'react';

export default function DelayTrendAnalyzer({ risk }) {
  if (!risk) return null;
  return (
    <div className="delay-analyzer-badge" title={risk['formula Breakdown']}>
      <span className="risk-pct">⚠️ Cascading Delay Risk: {risk.riskPercentage}%</span>
      <small className="ema-label">EMA: {risk.emaDelayMinutes}m delay</small>
    </div>
  );
}
