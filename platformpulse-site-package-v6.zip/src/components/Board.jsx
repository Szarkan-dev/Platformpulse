import React from 'react';
import CrowdDensityMeter from './CrowdDensityMeter';
import DelayTrendAnalyzer from './DelayTrendAnalyzer';
import LuggageCarousel from './LuggageCarousel';
import SeatAvailability from './SeatAvailability';

export default function Board({ services, onPin, pinnedIds }) {
  return (
    <div className="terminal-board">
      <div className="board-header">
        <div>SERVICE</div>
        <div>DESTINATION</div>
        <div>SCHEDULED / EST</div>
        <div>GATE / PLATFORM</div>
        <div>STATUS</div>
        <div>CROWD / DELAY RISK</div>
        <div>ACTION</div>
      </div>
      {services.map(s => {
        const isPinned = pinnedIds.includes(s.id);
        return (
          <div key={s.id} className={`board-row ${s.status === 'DELAYED' ? 'row-delayed' : ''}`}>
            <div className="service-col"><span className="badge">{s.type}</span> {s.serviceNumber}</div>
            <div className="dest-col">{s.destination}</div>
            <div className="time-col">{s.scheduled} <span className="est-time">({s.estimated})</span></div>
            <div className="gate-col">{s.gate}</div>
            <div className={`status-col status-${s.status.replace(' ', '-').toLowerCase()}`}>{s.status}</div>
            <div className="metrics-col">
              <CrowdDensityMeter passengers={s.crowdCount} sqFt={s.platformSqFt} />
              <DelayTrendAnalyzer risk={s.cascadingRisk} />
              {s.type === 'FLIGHT' && <LuggageCarousel flightNumber={s.serviceNumber} />}
              {s.type === 'TRAIN' && <SeatAvailability capacityPct={75} />}
            </div>
            <div className="action-col">
              <button onClick={() => onPin(s.id)} className={isPinned ? 'btn-pinned' : 'btn-pin'}>
                {isPinned ? '★ Pinned' : '☆ Pin Journey'}
              </button>
            </div>
          </div>
        );
      })}
    </div>
  );
}
