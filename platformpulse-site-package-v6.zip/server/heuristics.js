/**
 * PlatformPulse Heuristics Engine
 * Multi-Factor Cascading Delay Prediction Model
 */

function calculateEMADelay(historyMinutes, alpha = 0.3) {
  if (!historyMinutes || historyMinutes.length === 0) return 0;
  let ema = historyMinutes[0];
  for (let i = 1; i < historyMinutes.length; i++) {
    ema = alpha * historyMinutes[i] + (1 - alpha) * ema;
  }
  return ema;
}

function getPeakHourFactor(scheduledTime) {
  const hour = parseInt(scheduledTime.split(':')[0], 10);
  // Peak hours: 07:00-10:00 & 17:00-20:00
  if ((hour >= 7 && hour <= 10) || (hour >= 17 && hour <= 20)) {
    return 0.25;
  }
  return 0.05;
}

function calculateCascadingDelayRisk(historyMinutes, activePassengers, platformSqFt, scheduledTime) {
  const emaDelay = calculateEMADelay(historyMinutes, 0.35);
  const crowdIndex = activePassengers / (platformSqFt || 1000);
  const peakFactor = getPeakHourFactor(scheduledTime);

  const emaScore = Math.min(1.0, emaDelay / 60.0);
  const crowdScore = Math.min(1.0, crowdIndex / 0.8);

  const totalRisk = (emaScore * 0.45) + (crowdScore * 0.35) + (peakFactor * 0.20);
  const roundedRiskPct = Math.round(Math.min(0.99, Math.max(0.05, totalRisk)) * 100);

  return {
    riskPercentage: roundedRiskPct,
    emaDelayMinutes: Math.round(emaDelay * 10) / 10,
    crowdIndex: Math.round(crowdIndex * 100) / 100,
    peakFactor,
    formula Breakdown: `EMA(${emaDelay.toFixed(1)}m)*0.45 + CrowdIdx(${crowdIndex.toFixed(2)})*0.35 + Peak(${peakFactor})*0.20`
  };
}

module.exports = { calculateEMADelay, getPeakHourFactor, calculateCascadingDelayRisk };
