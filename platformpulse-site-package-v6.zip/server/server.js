const express = require('express');
const cors = require('cors');
const winston = require('winston');
const { calculateCascadingDelayRisk } = require('./heuristics');

const app = express();
app.use(cors());
app.use(express.json());

// Winston Logger
const logger = winston.createLogger({
  level: 'info',
  format: winston.format.json(),
  transports: [new winston.transports.Console()]
});

// Admin Authentication Middleware
const requireAdminAuth = (req, res, next) => {
  const apiKey = req.headers['x-admin-api-key'] || req.headers['authorization'];
  if (!apiKey || (apiKey !== 'admin-secret-key' && apiKey !== 'Bearer admin-token-123')) {
    logger.warn('Unauthorized attempt to trigger admin endpoint');
    return res.status(401).json({ error: 'Unauthorized: Valid Admin API Key required' });
  }
  next();
};

// In-Memory dataset for fast execution
let services = [
  { id: 1, serviceNumber: 'AI-101', type: 'FLIGHT', destination: 'New York (JFK)', scheduled: '08:30', estimated: '08:30', gate: 'B12', status: 'ON TIME', crowdCount: 140, platformSqFt: 3000, delayHistory: [0, 5, 0, 10, 0] },
  { id: 2, serviceNumber: '12723', type: 'TRAIN', destination: 'Telangana Express', scheduled: '08:45', estimated: '09:15', gate: 'Platform 4', status: 'DELAYED', crowdCount: 450, platformSqFt: 2500, delayHistory: [15, 30, 25, 45, 30] },
  { id: 3, serviceNumber: 'EK-502', type: 'FLIGHT', destination: 'Dubai (DXB)', scheduled: '09:10', estimated: '09:10', gate: 'A05', status: 'BOARDING', crowdCount: 220, platformSqFt: 2000, delayHistory: [0, 0, 10, 0, 5] },
  { id: 4, serviceNumber: '12951', type: 'TRAIN', destination: 'Mumbai Rajdhani', scheduled: '09:30', estimated: '09:30', gate: 'Platform 1', status: 'ON TIME', crowdCount: 180, platformSqFt: 3500, delayHistory: [0, 0, 0, 5, 0] }
];

let sseClients = [];

// SSE Telemetry Stream Endpoint with Heartbeat
app.get('/api/stream', (req, res) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders();

  sseClients.push(res);
  logger.info(`Client connected to SSE stream. Total: ${sseClients.length}`);

  // Heartbeat every 15s
  const heartbeat = setInterval(() => {
    res.write(': heartbeat ping\n\n');
  }, 15000);

  req.on('close', () => {
    clearInterval(heartbeat);
    sseClients = sseClients.filter(client => client !== res);
    logger.info('Client disconnected from SSE stream');
  });
});

// REST API: GET Services with Multi-Factor Delay Risk Calculation
app.get('/api/services', (req, res) => {
  const enriched = services.map(s => {
    const risk = calculateCascadingDelayRisk(s.delayHistory, s.crowdCount, s.platformSqFt, s.scheduled);
    return { ...s, cascadingRisk: risk };
  });
  res.json({ total: enriched.length, services: enriched });
});

// REST API: POST Simulate Action (Protected by Admin Auth)
app.post('/api/simulate', requireAdminAuth, (req, res) => {
  const { serviceId, action, newGate, delayMinutes } = req.body;
  const service = services.find(s => s.id === parseInt(serviceId));
  
  if (!service) {
    return res.status(404).json({ error: 'Service not found' });
  }

  if (action === 'GATE_CHANGE') {
    const oldGate = service.gate;
    service.gate = newGate || 'Platform 8';
    const alertPayload = { type: 'EMERGENCY_ALERT', message: `ATTENTION: Service ${service.serviceNumber} moved from ${oldGate} to ${service.gate}!`, timestamp: new Date().toISOString() };
    sseClients.forEach(c => c.write(`data: ${JSON.stringify(alertPayload)}\n\n`));
    logger.info(`Emergency gate change triggered for ${service.serviceNumber}`);
  } else if (action === 'ADD_DELAY') {
    service.status = 'DELAYED';
    service.delayHistory.push(delayMinutes || 20);
    logger.info(`Delay added for ${service.serviceNumber}`);
  }

  res.json({ message: 'Simulation executed successfully', service });
});

// Global Error Handler
app.use((err, req, res, next) => {
  logger.error(err.stack);
  res.status(500).json({ error: 'Internal Server Error', details: err.message });
});

if (require.main === module) {
  const PORT = process.env.PORT || 4000;
  app.listen(PORT, () => logger.info(`PlatformPulse Server running on port ${PORT}`));
}

module.exports = app;
