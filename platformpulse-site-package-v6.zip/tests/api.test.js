const request = require('supertest');
const app = require('../server/server');

describe('PlatformPulse REST API & Security Tests', () => {
  test('GET /api/services returns services with multi-factor delay risk', async () => {
    const res = await request(app).get('/api/services');
    expect(res.statusCode).toEqual(200);
    expect(res.body.services).toBeDefined();
    expect(res.body.services.length).toBeGreaterThan(0);
    expect(res.body.services[0].cascadingRisk).toHaveProperty('riskPercentage');
    expect(res.body.services[0].cascadingRisk).toHaveProperty('emaDelayMinutes');
  });

  test('POST /api/simulate fails without Admin Auth Key (401)', async () => {
    const res = await request(app).post('/api/simulate').send({ serviceId: 1, action: 'GATE_CHANGE' });
    expect(res.statusCode).toEqual(401);
    expect(res.body.error).toContain('Unauthorized');
  });

  test('POST /api/simulate succeeds with valid Admin Auth Key', async () => {
    const res = await request(app)
      .post('/api/simulate')
      .set('x-admin-api-key', 'admin-secret-key')
      .send({ serviceId: 1, action: 'GATE_CHANGE', newGate: 'Gate B9' });
    expect(res.statusCode).toEqual(200);
    expect(res.body.service.gate).toEqual('Gate B9');
  });
});
