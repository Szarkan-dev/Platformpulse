const { calculateEMADelay, getPeakHourFactor, calculateCascadingDelayRisk } = require('../server/heuristics');

describe('Multi-Factor Delay Heuristic Math Tests', () => {
  test('calculateEMADelay accurately computes exponential moving average', () => {
    const history = [10, 20, 30];
    const ema = calculateEMADelay(history, 0.5);
    expect(ema).toBe(22.5);
  });

  test('getPeakHourFactor identifies rush hours correctly', () => {
    expect(getPeakHourFactor('08:30')).toBe(0.25);
    expect(getPeakHourFactor('14:00')).toBe(0.05);
  });

  test('calculateCascadingDelayRisk returns complete risk breakdown payload', () => {
    const risk = calculateCascadingDelayRisk([15, 30, 45], 400, 2000, '08:30');
    expect(risk.riskPercentage).toBeGreaterThan(0);
    expect(risk.riskPercentage).toBeLessThanOrEqual(99);
    expect(risk.emaDelayMinutes).toBeGreaterThan(0);
    expect(risk).toHaveProperty('formula Breakdown');
  });
});
