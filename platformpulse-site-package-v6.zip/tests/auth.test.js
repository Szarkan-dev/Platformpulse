const request = require('supertest');
const app = require('../server/server');

describe('Admin Authentication Middleware Tests', () => {
  test('Rejects invalid token', async () => {
    const res = await request(app)
      .post('/api/simulate')
      .set('x-admin-api-key', 'wrong-key')
      .send({ serviceId: 1, action: 'ADD_DELAY', delayMinutes: 15 });
    expect(res.statusCode).toBe(401);
  });

  test('Accepts valid Bearer token', async () => {
    const res = await request(app)
      .post('/api/simulate')
      .set('authorization', 'Bearer admin-token-123')
      .send({ serviceId: 1, action: 'ADD_DELAY', delayMinutes: 15 });
    expect(res.statusCode).toBe(200);
  });
});
