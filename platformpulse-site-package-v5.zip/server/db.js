const Database = require('better-sqlite3');
const path = require('path');

const db = new Database(path.join(__dirname, 'platformpulse.db'));

db.exec(`
    CREATE TABLE IF NOT EXISTS TransitServices (
        id TEXT PRIMARY KEY,
        type TEXT NOT NULL,
        name TEXT NOT NULL,
        number TEXT NOT NULL,
        destination TEXT NOT NULL,
        scheduled_time TEXT NOT NULL,
        estimated_time TEXT NOT NULL,
        platform TEXT NOT NULL,
        status TEXT NOT NULL,
        crowd_level TEXT NOT NULL,
        capacity_pct INTEGER DEFAULT 50,
        history_delay_count INTEGER DEFAULT 0,
        total_journeys INTEGER DEFAULT 50
    );

    CREATE INDEX IF NOT EXISTS idx_services_status ON TransitServices(status);
    CREATE INDEX IF NOT EXISTS idx_services_sched ON TransitServices(scheduled_time);
`);

module.exports = db;
