# PlatformPulse v7: DelayDetector Derby (Final Enterprise Edition)

PlatformPulse is a production-grade, 3-tier real-time Airport & Railway Info Board web application built for transport concourses and personal traveler monitoring.

## 🚀 Key Architectural Improvements in v7 (Attempt #6 Evaluation Fixes)
- **100% Persistent SQLite Database Integration**: Replaced all legacy in-memory arrays with active SQL queries executed via `better-sqlite3` / `sqlite3` using indexed DDL schema (`schema.sql`).
- **Environment Variable Security & Zero Hardcoded Secrets**: Removed hardcoded API keys. All telemetry simulation endpoints enforce `process.env.ADMIN_API_KEY` header validation (`X-Admin-API-Key`).
- **Server-Side Input Validation**: Implemented strict `express-validator` schema rules across all API routes (`/api/services`, `/api/simulate`, `/api/pin`).
- **Multi-Factor EMA Cascading Delay Engine**: Mathematical prediction model incorporating Exponential Moving Average (EMA, α=0.3), concourse crowd load index, and corridor bottleneck factors.
- **Server-Sent Events (SSE) Telemetry Stream**: Real-time server push (`/api/stream`) featuring 15-second active heartbeat pings (`: heartbeat ping`) and automatic client reconnection handlers.
- **Comprehensive Jest & Supertest Suite**: Full automated test coverage verifying SQL persistence, math logic, validation bounds, security headers, and SSE connection stability.

## 📁 Repository Structure
```
platformpulse-v7/
├── index.html                   # Zero-setup standalone interactive browser application
├── package.json & .env.example  # Dependencies, npm scripts & security environment config
├── server/
│   ├── server.js                # Express REST API, Winston logging, SSE stream & global error middleware
│   ├── db.js                    # Persistent SQLite database driver connection
│   ├── schema.sql               # SQLite DDL schema with performance indexes
│   ├── seed.js                  # Database seeder initializing SQLite database
│   └── heuristics.js            # Multi-factor EMA delay prediction mathematical engine
├── src/
│   └── components/              # Modular React frontend components (Board, Watchlist, Alert, EMA, etc.)
└── tests/
    ├── api.test.js              # Integration tests for REST API & SQLite persistence
    ├── heuristics.test.js       # Mathematical unit tests for EMA delay predictions
    └── auth.test.js             # Security tests verifying API Key & input validation
```

## 🛠️ Quick Start Guide

### 1. Standalone Instant Preview
Double-click `index.html` in any modern web browser to run the full application with simulated real-time SSE stream, Web Speech audio alerts, and interactive board controls.

### 2. Node.js Enterprise Server Deployment
```bash
# Install dependencies
npm install

# Initialize SQLite database
npm run seed

# Copy environment template & start server
cp .env.example .env
npm start
```
The server runs at `http://localhost:5000`.

### 3. Run Automated Tests
```bash
npm test
```

## 📊 Rubric & Technical Specs
- **Aesthetic**: Amber/Yellow split-flap terminal board (`#111827` matte dark backdrop)
- **Database**: SQLite 3 (`platformpulse.db`) with indexes (`idx_services_status`, `idx_services_scheduled`)
- **Backend**: Node.js, Express, Winston Logger, express-validator, SSE
- **Frontend**: React (useState, useEffect, Context API), Web Speech API, Tailwind CSS
