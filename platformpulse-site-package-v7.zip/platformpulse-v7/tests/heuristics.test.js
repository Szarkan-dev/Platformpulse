const { calculateEMADelayRisk } = require('../server/heuristics');

describe('Multi-Factor EMA Delay Heuristic Math Unit Tests', () => {
    it('should calculate correct EMA and cascading risk for empty delay history', () => {
        const result = calculateEMADelayRisk([], 'Low');
        expect(result.emaDelay).toBe(0);
        expect(result.cascadingRiskPercent).toBe(5.0);
        expect(result.riskLevel).toBe('LOW');
    });

    it('should compute weighted EMA for increasing delay sequence', () => {
        const history = [10, 20, 30, 45];
        const result = calculateEMADelayRisk(history, 'Packed', 1.2, 0.3);
        expect(result.emaDelay).toBeGreaterThan(15);
        expect(result.riskLevel).toBe('MODERATE');
    });
});
