const request = require('supertest');
const app = require('../server/server');

describe('Security & Authentication Tests', () => {
    it('should reject invalid API keys', async () => {
        const res = await request(app)
            .post('/api/simulate')
            .set('X-Admin-API-Key', 'wrong-key')
            .send({ action: 'SIMULATE_GATE_CHANGE' });
        expect(res.statusCode).toEqual(401);
    });

    it('should reject invalid body validation parameters', async () => {
        const res = await request(app)
            .post('/api/simulate')
            .set('X-Admin-API-Key', 'platformpulse-secret-admin-key-2026')
            .send({ action: 'INVALID_ACTION' });
        expect(res.statusCode).toEqual(400);
        expect(res.body).toHaveProperty('error', 'Validation failed');
    });
});
