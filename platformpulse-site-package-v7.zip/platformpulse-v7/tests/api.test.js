const request = require('supertest');
const app = require('../server/server');

describe('PlatformPulse REST API & Integration Tests', () => {
    it('GET /api/services should return a paginated list of services from SQLite', async () => {
        const res = await request(app).get('/api/services?page=1&limit=5');
        expect(res.statusCode).toEqual(200);
        expect(res.body).toHaveProperty('data');
        expect(res.body.data.length).toBeGreaterThan(0);
        expect(res.body.data[0]).toHaveProperty('serviceNumber');
    });

    it('GET /api/services/:id/heuristics should calculate EMA delay risk mathematically', async () => {
        const res = await request(app).get('/api/services/S1/heuristics');
        expect(res.statusCode).toEqual(200);
        expect(res.body).toHaveProperty('analysis');
        expect(res.body.analysis).toHaveProperty('emaDelay');
        expect(res.body.analysis).toHaveProperty('cascadingRiskPercent');
    });

    it('POST /api/simulate without X-Admin-API-Key should return 401 Unauthorized', async () => {
        const res = await request(app).post('/api/simulate').send({ action: 'RESET_BOARD' });
        expect(res.statusCode).toEqual(401);
        expect(res.body).toHaveProperty('error');
    });

    it('POST /api/simulate with valid X-Admin-API-Key should succeed and broadcast SSE event', async () => {
        const res = await request(app)
            .post('/api/simulate')
            .set('X-Admin-API-Key', 'platformpulse-secret-admin-key-2026')
            .send({ action: 'RESET_BOARD' });
        expect(res.statusCode).toEqual(200);
        expect(res.body.success).toBe(true);
    });
});
