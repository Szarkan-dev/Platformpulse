/**
 * Multi-Factor Exponential Moving Average (EMA) Cascading Delay Prediction Model
 * Formula: EMA_t = alpha * Delay_t + (1 - alpha) * EMA_{t-1}
 * RiskScore = EMA_t * (1 + CrowdFactor) * BottleneckFactor
 */

function calculateEMADelayRisk(delayHistoryMinutes, crowdIndex, bottleneckFactor = 1.15, alpha = 0.3) {
    if (!delayHistoryMinutes || delayHistoryMinutes.length === 0) {
        return {
            emaDelay: 0,
            cascadingRiskPercent: 5.0,
            riskLevel: 'LOW',
            bottleneckFactor: bottleneckFactor
        };
    }

    let ema = delayHistoryMinutes[0];
    for (let i = 1; i < delayHistoryMinutes.length; i++) {
        ema = alpha * delayHistoryMinutes[i] + (1 - alpha) * ema;
    }

    let crowdFactor = 0.0;
    if (crowdIndex === 'Packed') crowdFactor = 0.45;
    else if (crowdIndex === 'Moderate') crowdFactor = 0.20;
    else crowdFactor = 0.05;

    const baseRisk = (ema / 60.0) * 100.0;
    const cascadingRiskPercent = Math.min(98.5, Math.max(2.0, baseRisk * (1 + crowdFactor) * bottleneckFactor));

    let riskLevel = 'LOW';
    if (cascadingRiskPercent >= 65.0) riskLevel = 'HIGH';
    else if (cascadingRiskPercent >= 35.0) riskLevel = 'MODERATE';

    return {
        emaDelay: parseFloat(ema.toFixed(1)),
        cascadingRiskPercent: parseFloat(cascadingRiskPercent.toFixed(1)),
        riskLevel: riskLevel,
        crowdFactor: crowdFactor,
        bottleneckFactor: bottleneckFactor
    };
}

module.exports = { calculateEMADelayRisk };
