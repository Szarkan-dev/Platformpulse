require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const winston = require('winston');
const { body, param, query, validationResult } = require('express-validator');
const db = require('./db');
const { calculateEMADelayRisk } = require('./heuristics');

const app = express();
const PORT = process.env.PORT || 5000;

// Winston Logger Setup
const logger = winston.createLogger({
    level: process.env.LOG_LEVEL || 'info',
    format: winston.format.combine(
        winston.format.timestamp(),
        winston.format.json()
    ),
    transports: [
        new winston.transports.Console()
    ]
});

app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors());
app.use(express.json());

// Logging Middleware
app.use((req, res, next) => {
    logger.info({ method: req.method, url: req.url, ip: req.ip });
    next();
});

// Admin Auth Middleware (Enforces process.env.ADMIN_API_KEY)
const requireAdminAuth = (req, res, next) => {
    const adminKey = req.headers['x-admin-api-key'] || req.query.adminKey;
    const expectedKey = process.env.ADMIN_API_KEY || 'platformpulse-secret-admin-key-2026';
    if (!adminKey || adminKey !== expectedKey) {
        logger.warn({ event: 'AUTH_FAILURE', ip: req.ip, providedKey: adminKey ? 'INVALID' : 'MISSING' });
        return res.status(401).json({ error: 'Unauthorized: Invalid or missing X-Admin-API-Key header' });
    }
    next();
};

// Validation Error Handler
const handleValidationErrors = (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        logger.warn({ event: 'VALIDATION_FAILED', errors: errors.array() });
        return res.status(400).json({ error: 'Validation failed', details: errors.array() });
    }
    next();
};

// Server-Sent Events (SSE) Stream with Active 15s Heartbeats
let sseClients = [];

app.get('/api/stream', (req, res) => {
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    res.flushHeaders();

    const clientId = Date.now();
    const newClient = { id: clientId, res };
    sseClients.push(newClient);
    logger.info({ event: 'SSE_CLIENT_CONNECTED', clientId, totalClients: sseClients.length });

    // Send initial ping
    res.write('data: {"type": "CONNECTED", "message": "Telemetry stream established"}\n\n');

    // Heartbeat Interval (15 seconds)
    const heartbeatInterval = setInterval(() => {
        try {
            res.write(': heartbeat ping\n\n');
        } catch (err) {
            logger.error({ event: 'SSE_HEARTBEAT_ERROR', clientId, error: err.message });
        }
    }, 15000);

    req.on('close', () => {
        clearInterval(heartbeatInterval);
        sseClients = sseClients.filter(c => c.id !== clientId);
        logger.info({ event: 'SSE_CLIENT_DISCONNECTED', clientId, remainingClients: sseClients.length });
    });
});

function broadcastEvent(type, payload) {
    const data = JSON.stringify({ type, payload, timestamp: new Date().toISOString() });
    sseClients.forEach(c => {
        try {
            c.res.write(`data: ${data}\n\n`);
        } catch (err) {
            logger.error({ event: 'SSE_BROADCAST_ERROR', clientId: c.id, error: err.message });
        }
    });
}

// REST Endpoints
app.get('/api/services', [
    query('page').optional().isInt({ min: 1 }),
    query('limit').optional().isInt({ min: 1, max: 50 }),
    query('status').optional().isIn(['On Time', 'Delayed', 'Boarding', 'Cancelled']),
    query('type').optional().isIn(['Train', 'Flight']),
    handleValidationErrors
], (req, res, next) => {
    try {
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 20;
        const offset = (page - 1) * limit;

        let queryStr = 'SELECT * FROM TransitServices WHERE 1=1';
        const params = [];

        if (req.query.status) {
            queryStr += ' AND status = ?';
            params.push(req.query.status);
        }
        if (req.query.type) {
            queryStr += ' AND type = ?';
            params.push(req.query.type);
        }

        queryStr += ' ORDER BY scheduledTime ASC LIMIT ? OFFSET ?';
        params.push(limit, offset);

        const services = db.prepare(queryStr).all(...params);
        const countResult = db.prepare('SELECT COUNT(*) as total FROM TransitServices').get();

        res.json({
            page,
            limit,
            total: countResult.total,
            data: services
        });
    } catch (err) {
        next(err);
    }
});

app.get('/api/services/:id/heuristics', [
    param('id').isString().notEmpty(),
    handleValidationErrors
], (req, res, next) => {
    try {
        const service = db.prepare('SELECT * FROM TransitServices WHERE id = ?').get(req.params.id);
        if (!service) return res.status(404).json({ error: 'Service not found' });

        const history = db.prepare('SELECT delayMinutes FROM DelayHistory WHERE serviceId = ? ORDER BY recordedAt ASC').all(req.params.id);
        const delayMins = history.map(h => h.delayMinutes);

        const densityRatio = service.activePassengers / (service.platformSqFt || 1200);
        let crowdIndex = 'Low';
        if (densityRatio > 0.35) crowdIndex = 'Packed';
        else if (densityRatio > 0.20) crowdIndex = 'Moderate';

        const riskAnalysis = calculateEMADelayRisk(delayMins.length > 0 ? delayMins : [service.delayMinutes], crowdIndex);

        res.json({
            serviceId: service.id,
            serviceNumber: service.serviceNumber,
            currentDelayMinutes: service.delayMinutes,
            history: delayMins,
            crowdIndex,
            analysis: riskAnalysis
        });
    } catch (err) {
        next(err);
    }
});

app.post('/api/simulate', [
    requireAdminAuth,
    body('action').isIn(['SIMULATE_GATE_CHANGE', 'SIMULATE_DELAY', 'RESET_BOARD']),
    body('serviceId').optional().isString(),
    body('newPlatform').optional().isString(),
    body('additionalDelayMinutes').optional().isInt({ min: 0 }),
    handleValidationErrors
], (req, res, next) => {
    try {
        const { action, serviceId, newPlatform, additionalDelayMinutes } = req.body;

        if (action === 'SIMULATE_GATE_CHANGE') {
            const targetId = serviceId || 'S1';
            const targetPlatform = newPlatform || 'Platform 8';
            const service = db.prepare('SELECT * FROM TransitServices WHERE id = ?').get(targetId);

            if (!service) return res.status(404).json({ error: 'Target service not found' });

            const oldPlatform = service.platform;
            db.prepare('UPDATE TransitServices set platform = ?, updatedAt = CURRENT_TIMESTAMP WHERE id = ?').run(targetPlatform, targetId);
            db.prepare('INSERT INTO GateLogs (serviceId, oldPlatform, newPlatform, reason) VALUES (?, ?, ?, ?)').run(targetId, oldPlatform, targetPlatform, 'Track Maintenance');

            const alertPayload = {
                serviceId: targetId,
                serviceNumber: service.serviceNumber,
                operator: service.operator,
                destination: service.destination,
                oldPlatform,
                newPlatform: targetPlatform,
                alertMessage: `ATTENTION: ${service.operator} (${service.serviceNumber}) re-assigned to ${targetPlatform}!`
            };

            broadcastEvent('EMERGENCY_GATE_CHANGE', alertPayload);
            return res.json({ success: true, action, alertPayload });
        }

        if (action === 'SIMULATE_DELAY') {
            const targetId = serviceId || 'S2';
            const addedDelay = additionalDelayMinutes || 25;

            const service = db.prepare('SELECT * FROM TransitServices WHERE id = ?').get(targetId);
            if (!service) return res.status(404).json({ error: 'Target service not found' });

            const newDelay = service.delayMinutes + addedDelay;
            db.prepare('UPDATE TransitServices set delayMinutes = ?, status = "Delayed", updatedAt = CURRENT_TIMESTAMP WHERE id = ?').run(newDelay, targetId);
            db.prepare('INSERT INTO DelayHistory (serviceId, delayMinutes, crowdIndex, bottleneckFactor) VALUES (?, ?, ?, ?)').run(targetId, newDelay, 'Packed', 1.2);

            const payload = { serviceId: targetId, newDelayMinutes: newDelay, status: 'Delayed' };
            broadcastEvent('SERVICE_DELAY_UPDATED', payload);
            return res.json({ success: true, action, payload });
        }

        if (action === 'RESET_BOARD') {
            db.prepare('UPDATE TransitServices set status = "On Time", delayMinutes = 0, platform = "Platform 4" WHERE id = "S1"').run();
            db.prepare('UPDATE TransitServices set status = "Delayed", delayMinutes = 30, platform = "Terminal 2" WHERE id = "S2"').run();
            broadcastEvent('BOARD_RESET', { message: 'Departure board reset to default telemetry' });
            return res.json({ success: true, action });
        }

    } catch (err) {
        next(err);
    }
});

// Global Centralized Error Middleware
app.use((err, req, res, next) => {
    logger.error({ event: 'UNHANDLED_ERROR', error: err.message, stack: err.stack });
    res.status(500).json({
        error: 'Internal Server Error',
        message: process.env.NODE_ENV === 'production' ? 'An unexpected error occurred on the server.' : err.message
    });
});

// Only listen if not imported in Jest test runner
if (process.env.NODE_ENV !== 'test') {
    app.listen(PORT, () => {
        logger.info(`PlatformPulse Enterprise Server running on port ${PORT}`);
    });
}

module.exports = app;
