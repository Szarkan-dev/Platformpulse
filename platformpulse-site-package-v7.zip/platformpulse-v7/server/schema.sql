-- PlatformPulse SQLite Database Schema
CREATE TABLE IF NOT EXISTS TransitServices (
    id TEXT PRIMARY KEY,
    serviceNumber TEXT NOT NULL,
    type TEXT CHECK(type IN ('Train', 'Flight')) NOT NULL,
    operator TEXT NOT NULL,
    destination TEXT NOT NULL,
    origin TEXT NOT NULL,
    scheduledTime TEXT NOT NULL,
    estimatedTime TEXT NOT NULL,
    status TEXT CHECK(status IN ('On Time', 'Delayed', 'Boarding', 'Cancelled')) NOT NULL,
    platform TEXT NOT NULL,
    gate TEXT NOT NULL,
    delayMinutes INTEGER DEFAULT 0,
    activePassengers INTEGER DEFAULT 0,
    platformSqFt INTEGER DEFAULT 1200,
    baggageCarousel TEXT,
    carouselCountdownMins INTEGER,
    seatCapacityPercent INTEGER DEFAULT 100,
    updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS GateLogs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    serviceId TEXT NOT NULL,
    oldPlatform TEXT NOT NULL,
    newPlatform TEXT NOT NULL,
    reason TEXT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(serviceId) REFERENCES TransitServices(id)
);

CREATE TABLE IF NOT EXISTS DelayHistory (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    serviceId TEXT NOT NULL,
    delayMinutes INTEGER NOT NULL,
    crowdIndex REAL NOT NULL,
    bottleneckFactor REAL NOT NULL,
    recordedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(serviceId) REFERENCES TransitServices(id)
);

CREATE TABLE IF NOT EXISTS PinnedAlerts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    userId TEXT DEFAULT 'default_user',
    serviceId TEXT NOT NULL,
    pinnedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(serviceId) REFERENCES TransitServices(id)
);

-- Performance Indexes
CREATE INDEX IF NOT EXISTS idx_services_status ON TransitServices(status);
CREATE INDEX IF NOT EXISTS idx_services_scheduled ON TransitServices(scheduledTime);
CREATE INDEX IF NOT EXISTS idx_gatelogs_service ON GateLogs(serviceId);
CREATE INDEX IF NOT EXISTS idx_delayhist_service ON DelayHistory(serviceId);
