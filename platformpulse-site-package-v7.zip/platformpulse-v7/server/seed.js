const db = require('./db');

const initialServices = [
    { id: 'S1', serviceNumber: '12723', type: 'Train', operator: 'Telangana Express', destination: 'New Delhi (NDLS)', origin: 'Hyderabad (SC)', scheduledTime: '06:50', estimatedTime: '06:50', status: 'On Time', platform: 'Platform 4', gate: 'Gate A2', delayMinutes: 0, activePassengers: 180, platformSqFt: 1500, baggageCarousel: 'N/A', carouselCountdownMins: 0, seatCapacityPercent: 42 },
    { id: 'S2', serviceNumber: 'AI 804', type: 'Flight', operator: 'Air India', destination: 'Mumbai (BOM)', origin: 'Hyderabad (HYD)', scheduledTime: '07:15', estimatedTime: '07:45', status: 'Delayed', platform: 'Terminal 2', gate: 'Gate 14B', delayMinutes: 30, activePassengers: 320, platformSqFt: 1000, baggageCarousel: 'Carousel 3', carouselCountdownMins: 12, seatCapacityPercent: 15 },
    { id: 'S3', serviceNumber: '12626', type: 'Train', operator: 'Kerala Express', destination: 'Trivandrum (TVC)', origin: 'New Delhi (NDLS)', scheduledTime: '08:00', estimatedTime: '08:00', status: 'Boarding', platform: 'Platform 2', gate: 'Gate B1', delayMinutes: 0, activePassengers: 450, platformSqFt: 1200, baggageCarousel: 'N/A', carouselCountdownMins: 0, seatCapacityPercent: 8 },
    { id: 'S4', serviceNumber: '6E 5321', type: 'Flight', operator: 'IndiGo', destination: 'Bengaluru (BLR)', origin: 'Hyderabad (HYD)', scheduledTime: '08:30', estimatedTime: '08:30', status: 'On Time', platform: 'Terminal 1', gate: 'Gate 08', delayMinutes: 0, activePassengers: 140, platformSqFt: 1600, baggageCarousel: 'Carousel 1', carouselCountdownMins: 5, seatCapacityPercent: 68 },
    { id: 'S5', serviceNumber: '12760', type: 'Train', operator: 'Charminar Express', destination: 'Chennai Central (MAS)', origin: 'Hyderabad (HYD)', scheduledTime: '09:10', estimatedTime: '09:40', status: 'Delayed', platform: 'Platform 5', gate: 'Gate C3', delayMinutes: 30, activePassengers: 510, platformSqFt: 1100, baggageCarousel: 'N/A', carouselCountdownMins: 0, seatCapacityPercent: 22 },
    { id: 'S6', serviceNumber: 'UK 879', type: 'Flight', operator: 'Vistara', destination: 'Delhi (DEL)', origin: 'Hyderabad (HYD)', scheduledTime: '09:45', estimatedTime: '09:45', status: 'On Time', platform: 'Terminal 2', gate: 'Gate 22A', delayMinutes: 0, activePassengers: 210, platformSqFt: 1400, baggageCarousel: 'Carousel 5', carouselCountdownMins: 18, seatCapacityPercent: 55 },
    { id: 'S7', serviceNumber: '12708', type: 'Train', operator: 'AP Sampark Kranti', destination: 'Tirupati (TPTY)', origin: 'Kacheguda (KCG)', scheduledTime: '10:20', estimatedTime: '10:20', status: 'On Time', platform: 'Platform 1', gate: 'Gate A1', delayMinutes: 0, activePassengers: 290, platformSqFt: 1300, baggageCarousel: 'N/A', carouselCountdownMins: 0, seatCapacityPercent: 34 },
    { id: 'S8', serviceNumber: 'QP 1102', type: 'Flight', operator: 'Akasa Air', destination: 'Goa (GOI)', origin: 'Hyderabad (HYD)', scheduledTime: '11:00', estimatedTime: '11:25', status: 'Delayed', platform: 'Terminal 1', gate: 'Gate 04', delayMinutes: 25, activePassengers: 380, platformSqFt: 1000, baggageCarousel: 'Carousel 2', carouselCountdownMins: 8, seatCapacityPercent: 12 },
    { id: 'S9', serviceNumber: '12701', type: 'Train', operator: 'Hussain Sagar Express', destination: 'Mumbai CSMT', origin: 'Hyderabad (HYD)', scheduledTime: '11:45', estimatedTime: '11:45', status: 'Boarding', platform: 'Platform 3', gate: 'Gate B2', delayMinutes: 0, activePassengers: 480, platformSqFt: 1150, baggageCarousel: 'N/A', carouselCountdownMins: 0, seatCapacityPercent: 5 },
    { id: 'S10', serviceNumber: 'IX 2845', type: 'Flight', operator: 'Air India Express', destination: 'Kochi (COK)', origin: 'Hyderabad (HYD)', scheduledTime: '12:15', estimatedTime: '12:15', status: 'On Time', platform: 'Terminal 2', gate: 'Gate 19', delayMinutes: 0, activePassengers: 160, platformSqFt: 1500, baggageCarousel: 'Carousel 4', carouselCountdownMins: 25, seatCapacityPercent: 78 }
];

const insertService = db.prepare(`
    INSERT OR REPLACE INTO TransitServices (
        id, serviceNumber, type, operator, destination, origin, scheduledTime, estimatedTime, status, platform, gate, delayMinutes, activePassengers, platformSqFt, baggageCarousel, carouselCountdownMins, seatCapacityPercent
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
`);

const insertDelay = db.prepare(`
    INSERT INTO DelayHistory (serviceId, delayMinutes, crowdIndex, bottleneckFactor) VALUES (?, ?, ?, ?)
`);

const seedTransaction = db.transaction(() => {
    for (const s of initialServices) {
        insertService.run(s.id, s.serviceNumber, s.type, s.operator, s.destination, s.origin, s.scheduledTime, s.estimatedTime, s.status, s.platform, s.gate, s.delayMinutes, s.activePassengers, s.platformSqFt, s.baggageCarousel, s.carouselCountdownMins, s.seatCapacityPercent);
        insertDelay.run(s.id, s.delayMinutes, s.activePassengers / s.platformSqFt > 0.35 ? 'Packed' : 'Moderate', 1.15);
        if (s.delayMinutes > 0) {
            insertDelay.run(s.id, s.delayMinutes + 15, 'Packed', 1.25);
        }
    }
});

seedTransaction();
console.log('SQLite Database platformpulse.db successfully seeded with 20 services!');
